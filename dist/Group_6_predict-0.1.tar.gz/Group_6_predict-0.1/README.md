# group6
Eskom predict group assignment 
Phiwa Making changes to check.
Tumisang editing function 6
